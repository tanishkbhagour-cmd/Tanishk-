# 🤖 AgentFlow AI

An early-stage, open-source website content analysis assistant built with Python, Streamlit, Beautiful Soup, and the OpenAI API.

## Features

- Extracts the title, meta description, headings, and visible text from a public HTML page.
- Generates an AI-written website overview, audience assessment, improvement suggestions, and next steps.
- Provides a simple Streamlit interface.

## Getting started

1. Install Python 3.10 or later.
2. Clone this repository and open the project directory.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Set your API key as an environment variable (do not commit it):

   macOS/Linux:
   ```bash
   export OPENAI_API_KEY="your_api_key_here"
   ```

   Windows PowerShell:
   ```powershell
   $env:OPENAI_API_KEY="your_api_key_here"
   ```

6. Start the app:

   ```bash
   streamlit run app.py
   ```

## Limitations and safety

- Requires a valid OpenAI API key; API usage may incur charges.
- Only analyzes public HTML content, not logged-in pages or JavaScript-rendered content.
- This prototype does not implement robots.txt checks, private-network URL blocking, or rate limiting. Only use it locally with websites you own or are authorized to analyze. Do not deploy it publicly without adding SSRF protection and other safeguards.
- AI suggestions are based on extracted text, not a comprehensive technical, SEO, accessibility, or security audit.
- Never put API keys or other secrets in GitHub commits.

## Contributing

Issues, documentation improvements, and pull requests are welcome. Please describe the change and test it locally before submitting.

## License

MIT. See [LICENSE](LICENSE).
